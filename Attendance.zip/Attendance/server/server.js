const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const User = require("./models/User");
const Attendance = require("./models/Attendance");

const app = express();
const PORT = 5000;
const MONGO_URI = "mongodb://localhost:27017/attendance";

app.use(cors());
app.use(bodyParser.json());

// Connect to MongoDB
mongoose
  .connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Allowed IP prefixes for office Wi-Fi
const allowedIPs = ["192.168.1.", "10.0.0.", "192.168.137.", "192.0.0."];

// File to store persistent .local IP mappings
const localIPFile = path.join(__dirname, "localIPMap.json");

// Load mapping from file or create empty object
let localIPMap = {};
if (fs.existsSync(localIPFile)) {
  try {
    localIPMap = JSON.parse(fs.readFileSync(localIPFile, "utf8"));
    console.log("Loaded .local IP mappings from file");
  } catch (err) {
    console.error("Error reading localIPMap.json:", err);
    localIPMap = {};
  }
}

// Save mapping to file
function saveLocalIPMap() {
  fs.writeFileSync(localIPFile, JSON.stringify(localIPMap, null, 2), "utf8");
}

// Check if IP is in allowed range
function isIPAllowed(ip) {
  return allowedIPs.some((prefix) => ip.startsWith(prefix));
}

// Map .local hostname to deterministic 192.0.0.x IP with persistence
function mapLocalToIP(hostname) {
  if (localIPMap[hostname]) return localIPMap[hostname];

  // Create a hash of the hostname
  const hash = crypto.createHash("md5").update(hostname).digest("hex");
  // Take last 2 digits as a number between 1-254
  const lastByte = parseInt(hash.slice(-2), 16) % 254 + 1;
  const mappedIP = `192.0.0.${lastByte}`;

  // Store mapping and save to file
  localIPMap[hostname] = mappedIP;
  saveLocalIPMap();

  return mappedIP;
}

// ✅ Register user with full profile
app.post("/api/register", async (req, res) => {
  const { employeeId, name, password, address, email, mobile, dob, department, role } = req.body;

  if (!employeeId || !name || !password || !address || !email || !mobile || !dob || !department) {
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    const existing = await User.findOne({ employeeId });
    if (existing) return res.status(400).json({ message: "Employee already registered" });

    const user = new User({
      employeeId,
      name,
      password,
      address,
      email,
      mobile,
      dob,
      department,
      role: role || "employee"
    });

    await user.save();
    res.status(201).json({ message: "Registered successfully" });
  } catch (err) {
    console.error("Registration error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ Login user
app.post("/api/login", async (req, res) => {
  const { employeeId, password } = req.body;

  try {
    const user = await User.findOne({ employeeId, password });
    if (!user) return res.status(401).json({ message: "Invalid credentials" });

    res.status(200).json({ message: "Login successful", employeeId, role: user.role });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ Mark attendance with IP validation and persistent .local mapping
app.post("/api/attendance", async (req, res) => {
  try {
    const { employeeId, ip: clientIp } = req.body;

    if (!employeeId || !clientIp) {
      return res.status(400).json({ message: "Missing employeeId or ip" });
    }

    // Map .local hostname to 192.0.0.x
    const ip = clientIp.endsWith(".local") ? mapLocalToIP(clientIp) : clientIp;

    // Validate against allowed IPs
    if (!isIPAllowed(ip)) {
      return res.status(403).json({ message: "IP not allowed - Must be connected to office Wi-Fi" });
    }

    const now = new Date();
    const date = now.toISOString().slice(0, 10);
    const time = now.toTimeString().slice(0, 8);

    // Check if attendance already marked today
    const existing = await Attendance.findOne({ employeeId, date });
    if (existing) {
      return res.status(200).json({ message: "Attendance already marked today", attendance: existing });
    }

    // Save new attendance with the **mapped IP**
    const newAttendance = new Attendance({ employeeId, date, time, ip });
    await newAttendance.save();

    res.status(200).json({ message: "Attendance marked successfully", attendance: newAttendance });
  } catch (error) {
    console.error("Error in /api/attendance:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ Get all attendance records (admin)
app.get("/api/attendance/all", async (req, res) => {
  try {
    const records = await Attendance.find().sort({ date: -1, time: -1 });
    res.json(records);
  } catch (error) {
    console.error("Error fetching attendance records:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ Get all registered employees (admin)
app.get("/api/employees", async (req, res) => {
  try {
    const users = await User.find({}, "-password"); // exclude passwords
    res.json(users);
  } catch (error) {
    console.error("Error fetching employee data:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ Delete an employee by ID (admin)
app.delete("/api/employees/:id", async (req, res) => {
  try {
    const deletedUser = await User.findByIdAndDelete(req.params.id);
    if (!deletedUser) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.status(200).json({ message: "Employee deleted successfully" });
  } catch (error) {
    console.error("Error deleting employee:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ Health check
app.get("/", (req, res) => {
  res.send("Auto Attendance Backend is running");
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
