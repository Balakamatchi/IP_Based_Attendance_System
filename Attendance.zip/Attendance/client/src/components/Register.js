import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Register() {
  const [formData, setFormData] = useState({
    employeeId: "",
    name: "",
    password: "",
    address: "",
    email: "",
    mobile: "",
    dob: "",
    department: ""
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async () => {
    const { employeeId, name, password, address, email, mobile, dob, department } = formData;

    // Basic validation
    if (!employeeId || !name || !password || !address || !email || !mobile || !dob || !department) {
      alert("All fields are required.");
      return;
    }

    try {
      const res = await axios.post("http://localhost:5000/api/register", {
        ...formData,
        role: "employee"
      });

      if (res.data?.message) {
        alert(res.data.message);
        navigate("/");
      } else {
        alert("Registration successful.");
        navigate("/");
      }
    } catch (err) {
      console.error("Registration Error:", err);
      alert(err.response?.data?.message || "Server Error. Please try again later.");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2>Register as Employee</h2>
        <input name="name" type="text" placeholder="Full Name" value={formData.name} onChange={handleChange} style={styles.input} />
        <input name="employeeId" type="text" placeholder="Employee ID" value={formData.employeeId} onChange={handleChange} style={styles.input} />
        <input name="password" type="password" placeholder="Password" value={formData.password} onChange={handleChange} style={styles.input} />
        <input name="address" type="text" placeholder="Address" value={formData.address} onChange={handleChange} style={styles.input} />
        <input name="email" type="email" placeholder="Email" value={formData.email} onChange={handleChange} style={styles.input} />
        <input name="mobile" type="tel" placeholder="Mobile Number" value={formData.mobile} onChange={handleChange} style={styles.input} />
        <input name="dob" type="date" value={formData.dob} onChange={handleChange} style={styles.input} />
        <select name="department" value={formData.department} onChange={handleChange} style={styles.input}>
          <option value="">Select Department</option>
          <option value="Software Development">Software Engineers</option>
          <option value="Quality Assurance">Data Scientists</option>
          <option value="Human Resources">Product Managers</option>
          <option value="Technical Support">AI/ML Engineers</option>
          <option value="IT Operations">Network Administrators</option>
          <option value="IT Operations">Security Specialists</option>
          <option value="IT Operations">Customer Support Engineers</option>
          <option value="IT Operations">UX/UI Designers</option>
          <option value="IT Operations">Sales and Marketing</option>
        </select>
        <button onClick={handleRegister} style={styles.button}>Register</button>
        <p>
          Already registered?{" "}
          <span onClick={() => navigate("/")} style={styles.link}>Login here</span>
        </p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh",
    background: "linear-gradient(to right, #b2fefa, #0ed2f7)",
  },
  card: {
    padding: 30, backgroundColor: "#fff", borderRadius: 10,
    boxShadow: "0 5px 15px rgba(0,0,0,0.2)", width: 320, textAlign: "center",
    boxSizing: "border-box",
  },
  input: {
    width: "100%", padding: 10, margin: "10px 0", borderRadius: 6, border: "1px solid #ccc",
    fontSize: 14, boxSizing: "border-box",
  },
  button: {
    width: "100%", padding: 10, backgroundColor: "#28a745", color: "#fff", border: "none", borderRadius: 6,
    cursor: "pointer",
  },
  link: {
    color: "#007bff", cursor: "pointer", textDecoration: "underline",
  }
};

export default Register;
