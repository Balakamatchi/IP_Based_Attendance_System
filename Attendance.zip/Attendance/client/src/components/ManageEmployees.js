import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function ManageEmployees() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [deletingId, setDeletingId] = useState(null);

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/employees");
      setEmployees(res.data);
    } catch {
      setError("Failed to fetch employee data.");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure to delete this employee?")) return;
    setDeletingId(id);
    try {
      await axios.delete(`http://localhost:5000/api/employees/${id}`);
      setEmployees(employees.filter((emp) => emp._id !== id));
    } catch {
      alert("Failed to delete employee.");
    } finally {
      setDeletingId(null);
    }
  };

  if (loading) return <p style={loadingStyle}>Loading employees...</p>;
  if (error) return <p style={errorStyle}>{error}</p>;

  return (
    <div style={containerStyle}>
      <h2 style={headerStyle}>👥 Manage Employee Accounts</h2>
      <Link to="/Login" style={linkStyle}>
        ← Back to Login
      </Link>
      <div style={cardStyle}>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Employee ID</th>
              <th style={thStyle}>Name</th>
              <th style={thStyle}>Email</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {employees.length === 0 ? (
              <tr><td colSpan={4} style={tdStyle}>No employees found.</td></tr>
            ) : (
              employees.map((emp) => (
                <tr key={emp._id} style={trStyle}>
                  <td style={tdStyle}>{emp.employeeId}</td>
                  <td style={tdStyle}>{emp.name}</td>
                  <td style={tdStyle}>{emp.email}</td>
                  <td style={tdStyle}>
                    <button
                      onClick={() => handleDelete(emp._id)}
                      disabled={deletingId === emp._id}
                      style={buttonStyle(deletingId === emp._id)}
                    >
                      {deletingId === emp._id ? "Deleting..." : "Delete"}
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const containerStyle = { padding: 30, fontFamily: "Segoe UI" };
const headerStyle = { marginBottom: 10, color: "#007bff" };
const linkStyle = { marginBottom: 15, display: "inline-block", color: "#333", textDecoration: "none" };
const cardStyle = { boxShadow: "0 2px 8px rgba(0,0,0,0.1)", borderRadius: 10, overflowX: "auto" };
const tableStyle = { width: "100%", borderCollapse: "collapse" };
const thStyle = { padding: 12, background: "#007bff", color: "#fff", textAlign: "left" };
const tdStyle = { padding: 10, background: "#f9f9f9" };
const trStyle = { borderBottom: "1px solid #ddd", transition: "0.3s" };
const buttonStyle = (isDisabled) => ({
  padding: "6px 12px",
  color: "#fff",
  backgroundColor: isDisabled ? "#888" : "#dc3545",
  border: "none",
  borderRadius: 4,
  cursor: isDisabled ? "not-allowed" : "pointer",
  transition: "0.2s",
});
const loadingStyle = { padding: 30 };
const errorStyle = { color: "red", padding: 30 };

export default ManageEmployees;
