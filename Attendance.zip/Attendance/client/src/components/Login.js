// Login.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Login() {
  const [role, setRole] = useState("employee");
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (!id || !password) {
      setMessage("Please fill all fields");
      return;
    }
    if (role === "admin") {
      if (id === "Cupid" && password === "27102024") {
        navigate("/dashboard", { state: { role } });
      } else {
        setMessage("Invalid Admin Credentials");
      }
    } else {
      try {
        const res = await axios.post("http://localhost:5000/api/login", {
          employeeId: id,
          password,
        });
        setMessage(res.data.message);
        navigate("/dashboard", {
          state: { employeeId: res.data.employeeId, role: res.data.role },
        });
      } catch (err) {
        setMessage(err.response?.data?.message || "Login failed");
      }
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2>Login</h2>
        <select value={role} onChange={e => setRole(e.target.value)} style={styles.input}>
          <option value="employee">Employee</option>
          <option value="admin">Admin</option>
        </select>
        <input
          style={styles.input}
          type="text"
          placeholder={role === "admin" ? "Admin ID" : "Employee ID"}
          value={id}
          onChange={e => setId(e.target.value)}
        />
        <input
          style={styles.input}
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />
        <button style={{ ...styles.button, backgroundColor: "#007bff" }} onClick={handleLogin}>Login</button>
        {message && <p style={{ color: "red", marginTop: 10 }}>{message}</p>}
        {role === "employee" && (
          <p>
            New user?{" "}
            <span style={styles.link} onClick={() => navigate("/register")}>
              Register here
            </span>
          </p>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh",
    background: "linear-gradient(to right, #83a4d4, #b6fbff)",
  },
  card: {
    padding: 30, backgroundColor: "#fff", borderRadius: 10,
    boxShadow: "0 5px 15px rgba(0,0,0,0.2)", width: 320, textAlign: "center",
    boxSizing: "border-box",
  },
  input: {
    width: "100%", padding: 10, margin: "10px 0", borderRadius: 6, border: "1px solid #ccc",
    boxSizing: "border-box",
  },
  button: {
    width: "100%", padding: 10, color: "#fff", border: "none", borderRadius: 6,
    cursor: "pointer",
  },
  link: {
    color: "#007bff", cursor: "pointer", textDecoration: "underline",
  }
};

export default Login;
