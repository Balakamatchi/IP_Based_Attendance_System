import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

function Dashboard() {
  const { state } = useLocation();
  const isAdmin = state?.role === "admin";
  const employeeId = state?.employeeId;
  const navigate = useNavigate();

  const [ip, setIP] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [attendanceMarked, setAttendanceMarked] = useState(false);

  const getLocalIP = () => {
    return new Promise((resolve, reject) => {
      const rtc = new RTCPeerConnection({ iceServers: [] });
      rtc.createDataChannel("");
      rtc.onicecandidate = (event) => {
        if (!event.candidate) return;
        const ipMatch = event.candidate.candidate.split(" ")[4];
        if (ipMatch && ipMatch.includes(".")) resolve(ipMatch);
      };
      rtc.createOffer().then((offer) => rtc.setLocalDescription(offer));
    });
  };

  const handleMarkAttendance = async () => {
    setLoading(true);
    setMessage("Detecting IP...");
    try {
      const localIP = await getLocalIP();
      setIP(localIP);

    
      const res = await axios.post("http://localhost:5000/api/attendance", {
        employeeId,
        ip: localIP,
      });
      
      setMessage(res.data.message);
      setAttendanceMarked(true);
      
      // ✅ Use backend-mapped IP instead of raw localIP
      if (res.data.attendance?.ip) {
        setIP(res.data.attendance.ip);
      } else {
        setIP(localIP);
      }
    } catch (err) {
      console.error(err);
      setMessage("Failed to mark attendance. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h1 style={styles.title}>
          Welcome {isAdmin ? "Admin" : `Employee ${employeeId}`}
        </h1>

        <p style={styles.subtitle}>
          This is your {isAdmin ? "admin" : "employee"} dashboard.
        </p>

        <div style={styles.section}>
          {isAdmin ? (
            <>
              <h2 style={styles.sectionTitle}>Admin Panel</h2>
              <button
                style={styles.actionButton}
                onClick={() => navigate("/admin/attendance-history")}
              >
                📋 View All Employee Attendance
              </button>
              <button
                style={styles.actionButton}
                onClick={() => navigate("/admin/manage-employees")}
              >
                👤 Manage Employee Accounts
              </button>
            </>
          ) : (
            <>
              <button
                onClick={handleMarkAttendance}
                disabled={attendanceMarked || loading}
                style={{
                  ...styles.button,
                  backgroundColor: attendanceMarked ? "#4caf50" : "#007bff",
                  cursor: attendanceMarked || loading ? "not-allowed" : "pointer",
                }}
              >
                {loading
                  ? "Marking..."
                  : attendanceMarked
                  ? "Marked"
                  : "Mark Today's Attendance"}
              </button>
              <p style={styles.message}>{message}</p>
              {ip && (
                <p style={{ fontSize: 12, color: "#666" }}>
                  Detected IP: {ip}
                </p>
              )}
            </>
          )}
        </div>

        <p style={{ marginTop: 20 }}>
          <button onClick={() => navigate("/login")} style={styles.loginLink}>
            🔐 Back to Login
          </button>
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #e0f7fa, #f3f4f6)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontFamily: "Segoe UI, sans-serif",
  },
  card: {
    backgroundColor: "#fff",
    padding: "40px 50px",
    borderRadius: 12,
    boxShadow: "0 6px 18px rgba(0,0,0,0.1)",
    textAlign: "center",
    width: 450,
  },
  title: {
    fontSize: 28,
    marginBottom: 10,
    color: "#333",
  },
  subtitle: {
    fontSize: 16,
    color: "#555",
    marginBottom: 30,
  },
  section: {
    textAlign: "left",
  },
  sectionTitle: {
    fontSize: 20,
    color: "#007bff",
    marginBottom: 10,
  },
  actionButton: {
    width: "100%",
    padding: 12,
    marginTop: 10,
    fontSize: 16,
    cursor: "pointer",
    borderRadius: 8,
    border: "1px solid #007bff",
    backgroundColor: "#fff",
    color: "#007bff",
    fontWeight: "600",
  },
  button: {
    marginTop: 20,
    width: "100%",
    padding: 12,
    fontSize: 16,
    color: "#fff",
    border: "none",
    borderRadius: 8,
    fontWeight: "bold",
  },
  message: {
    marginTop: 15,
    fontSize: 14,
    color: "#444",
  },
  loginLink: {
    background: "none",
    border: "none",
    color: "#007bff",
    textDecoration: "underline",
    cursor: "pointer",
    fontSize: 14,
    padding: 0,
    fontWeight: "500",
  },
};

export default Dashboard;
