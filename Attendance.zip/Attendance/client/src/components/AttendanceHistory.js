import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function AttendanceHistory() {
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchAttendance() {
      try {
        const res = await axios.get("http://localhost:5000/api/attendance/all");
        setAttendanceRecords(res.data);
      } catch (err) {
        setError("Failed to fetch attendance data.");
      } finally {
        setLoading(false);
      }
    }
    fetchAttendance();
  }, []);

  if (loading) return <p style={loadingStyle}>Loading attendance records...</p>;
  if (error) return <p style={errorStyle}>{error}</p>;

  return (
    <div style={containerStyle}>
      <h2 style={headerStyle}>📊 Employee Attendance History</h2>
      <Link to="/Login" style={linkStyle}>
        ← Back to Login
      </Link>
      <div style={cardStyle}>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Employee ID</th>
              <th style={thStyle}>Date</th>
              <th style={thStyle}>Time</th>
              <th style={thStyle}>IP Address</th>
              <th style={thStyle}>Status</th>
            </tr>
          </thead>
          <tbody>
            {attendanceRecords.length === 0 ? (
              <tr><td colSpan={5} style={tdStyle}>No attendance records found.</td></tr>
            ) : (
              attendanceRecords.map((record) => (
                <tr key={record._id} style={trStyle}>
                  <td style={tdStyle}>{record.employeeId}</td>
                  <td style={tdStyle}>{new Date(record.date).toLocaleDateString()}</td>
                  <td style={tdStyle}>{record.time}</td>
                  <td style={tdStyle}>{record.ip}</td>
                  <td style={tdStyle}>{record.status || "Present"}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const containerStyle = { padding: 30, fontFamily: "Segoe UI" };
const headerStyle = { marginBottom: 10, color: "#007bff" };
const linkStyle = { marginBottom: 15, display: "inline-block", color: "#333", textDecoration: "none" };
const cardStyle = { boxShadow: "0 2px 8px rgba(0,0,0,0.1)", borderRadius: 10, overflowX: "auto" };
const tableStyle = { width: "100%", borderCollapse: "collapse" };
const thStyle = { padding: 12, background: "#007bff", color: "#fff", textAlign: "left" };
const tdStyle = { padding: 10, background: "#f9f9f9" };
const trStyle = { borderBottom: "1px solid #ddd", transition: "0.3s" };
const loadingStyle = { padding: 30 };
const errorStyle = { color: "red", padding: 30 };

export default AttendanceHistory;
